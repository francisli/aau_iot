// Call the console.log function.
console.log("Hello World");