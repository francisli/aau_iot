echo 'npm installs'
npm install
